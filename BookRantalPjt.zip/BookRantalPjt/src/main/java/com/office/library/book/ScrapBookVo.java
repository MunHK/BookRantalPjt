package com.office.library.book;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ScrapBookVo {
	int b_no;
	String s_thumbnail;
	String s_name;
	String s_author;	
	String s_publisher;
	String s_publish_year;	
	String s_isbn;
	String s_call_number; 
	String s_reg_date;
	String s_mod_date;
}
