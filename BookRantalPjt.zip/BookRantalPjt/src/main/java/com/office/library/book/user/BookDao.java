package com.office.library.book.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.office.library.book.BookVo;
import com.office.library.book.HopeBookVo;
import com.office.library.book.RentalBookVo;

@Component
//@Component("user.BookDao")
public class BookDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<BookVo> selectBooksBySearch(BookVo bookVo) {
		System.out.println("[BookDao] selectBooks()");
		
		String sql =  "SELECT * FROM tbl_book "
					+ "WHERE b_name LIKE ? "
					+ "ORDER BY b_no DESC";
		
		List<BookVo> bookVos = null;
		
		try {
			
			RowMapper<BookVo> rowMapper = BeanPropertyRowMapper.newInstance(BookVo.class);
			bookVos = jdbcTemplate.query(sql, rowMapper, "%" + bookVo.getB_name() + "%");
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return bookVos.size() > 0 ? bookVos : null;
		
	}
	
//	public BookVo selectBook(int b_no) {
//		System.out.println("[BookDao] selectBook()");
//		
//		String sql = "SELECT * FROM tbl_book WHERE b_no = ?";
//		
//		List<BookVo> bookVos = null;
//		
//		try {
//			
//			bookVos = jdbcTemplate.query(sql, new RowMapper<BookVo>() {
//
//				@Override
//				public BookVo mapRow(ResultSet rs, int rowNum) throws SQLException {
//					
//					BookVo bookVo = new BookVo();
//					
//					bookVo.setB_no(rs.getInt("b_no"));
//					bookVo.setB_thumbnail(rs.getString("b_thumbnail"));
//					bookVo.setB_name(rs.getString("b_name"));
//					bookVo.setB_author(rs.getString("b_author"));
//					bookVo.setB_publisher(rs.getString("b_publisher"));
//					bookVo.setB_publish_year(rs.getString("b_publish_year"));
//					bookVo.setB_isbn(rs.getString("b_isbn"));
//					bookVo.setB_call_number(rs.getString("b_call_number"));
//					bookVo.setB_rantal_able(rs.getInt("b_rantal_able"));
//					bookVo.setB_reg_date(rs.getString("b_reg_date"));
//					bookVo.setB_mod_date(rs.getString("b_mod_date"));
//					
//					return bookVo;
//					
//				}
//				
//			}, b_no);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			
//		}
//		
//		return bookVos.size() > 0 ? bookVos.get(0) : null;
//		
//	}
	
	public BookVo selectBook(int b_no) {
		System.out.println("[BookDao] selectBook()");
		
		String sql = "SELECT * FROM tbl_book WHERE b_no = ?";
		
		List<BookVo> bookVos = null;
		
		try {
			
			RowMapper<BookVo> rowMapper = BeanPropertyRowMapper.newInstance(BookVo.class);
			bookVos = jdbcTemplate.query(sql, rowMapper, b_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return bookVos.size() > 0 ? bookVos.get(0) : null;
		
	}
	public RentalBookVo selectRentalBook(int u_m_no) {
		System.out.println("[BookDao] selectRentalBook()");
		
		String sql =  "SELECT * FROM tbl_rental_book rb "
				+ "JOIN tbl_book b "
				+ "ON rb.b_no = b.b_no "
				+ "JOIN tbl_user_member um "
				+ "ON rb.u_m_no = um.u_m_no "
				+ "WHERE rb.u_m_no = ? AND rb.rb_end_date = '1000-01-01'";
		
		List<RentalBookVo> rentalbookVos = null;
		
		try {
			
			RowMapper<RentalBookVo> rowMapper = BeanPropertyRowMapper.newInstance(RentalBookVo.class);
			rentalbookVos = jdbcTemplate.query(sql, rowMapper, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return rentalbookVos.size() > 0 ? rentalbookVos.get(0) : null;
		
	}
	public int insertRentalBook(int b_no, int u_m_no) {
		System.out.println("[BookDao] insertRentalBook()");
		
		String sql =  "INSERT INTO tbl_rental_book(b_no, u_m_no, rb_start_date, rb_reg_date, rb_mod_date) "
					+ "VALUES(?, ?, NOW(), NOW(), NOW())";
		
		int result = -1;
		
		try {
			
			result = jdbcTemplate.update(sql, b_no, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return result;
		
	}
	public int insertReserveBook(int b_no, int u_m_no) {
		System.out.println("[BookDao] insertReserveBook()");
		
		String sql =  "INSERT INTO tbl_reserve_book(b_no, u_m_no, rv_start_date, rv_reg_date, rv_mod_date) "
					+ "VALUES(?, ?, NOW(), NOW(), NOW())";
		
		int result = -1;
		
		try {
			
			result = jdbcTemplate.update(sql, b_no, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return result;
		
	}
	public int updateReserveBookAble(int b_no) {
		System.out.println("[BookDao] updateReserveBookAble()");
		
		String sql =  "UPDATE tbl_book "
					+ "SET b_reserve_able = 0 "
					+ "WHERE b_no = ?";
		
		int result=-1;
		try {
			
			result=jdbcTemplate.update(sql, b_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return result;
	}
	
	public void updateRentalBookAble(int b_no) {
		System.out.println("[BookDao] updateRentalBookAble()");
		
		String sql =  "UPDATE tbl_book "
					+ "SET b_rantal_able = 0 "
					+ "WHERE b_no = ?";
		
		try {
			
			jdbcTemplate.update(sql, b_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
	}
	
	public List<RentalBookVo> selectRentalBooks(int u_m_no) {
		System.out.println("[BookDao] selectRentalBooks()");
		
		String sql =  "SELECT * FROM tbl_rental_book rb "
					+ "JOIN tbl_book b "
					+ "ON rb.b_no = b.b_no "
					+ "JOIN tbl_user_member um "
					+ "ON rb.u_m_no = um.u_m_no "
					+ "WHERE rb.u_m_no = ? AND rb.rb_end_date = '1000-01-01'";
		
		List<RentalBookVo> rentalBookVos = new ArrayList<RentalBookVo>();
		
		try {
			
			RowMapper<RentalBookVo> rowMapper = BeanPropertyRowMapper.newInstance(RentalBookVo.class);
			rentalBookVos = jdbcTemplate.query(sql, rowMapper, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return rentalBookVos;
		
	}
	
	public int extendRentalBook(int rb_no,String rb_ex_end) {
		System.out.println("[BookDao] extendRentalBook()");
		
		String sql =  "UPDATE tbl_rental_book "
					+ "SET rb_ex_end = DATE_ADD(?, INTERVAL 1 WEEK)  "
					+ "WHERE rb_no = ?";
		
		System.out.println("rb_no: " + rb_no);
	    System.out.println("rb_ex_end: " + rb_ex_end);
		int result = -1;
		
		try {
			
			result = jdbcTemplate.update(sql, rb_ex_end ,rb_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return result;
	}
	public int updateBook(int b_no) {
		System.out.println("[BookDao] updateRentalBook()");
		
		String sql =  "UPDATE tbl_book "
					+ "SET b_extend_able = 0 "
					+ "WHERE b_no = ?";
		
		int result = -1;
		
		try {
			
			result = jdbcTemplate.update(sql, b_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return result;
		
	}
	public List<RentalBookVo> selectRentalBookHistory(int u_m_no) {
		System.out.println("[BookDao] selectRentalBooks()");
		
		String sql =  "SELECT * FROM tbl_rental_book rb "
					+ "JOIN tbl_book b "
					+ "ON rb.b_no = b.b_no "
					+ "JOIN tbl_user_member um "
					+ "ON rb.u_m_no = um.u_m_no "
					+ "WHERE rb.u_m_no = ? "
					+ "ORDER BY rb.rb_reg_date DESC";
		
		List<RentalBookVo> rentalBookVos = new ArrayList<RentalBookVo>();
		
		try {
			
			RowMapper<RentalBookVo> rowMapper = BeanPropertyRowMapper.newInstance(RentalBookVo.class);
			rentalBookVos = jdbcTemplate.query(sql, rowMapper, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return rentalBookVos;
		
	}
	
	public int insertHopeBook(HopeBookVo hopeBookVo) {
		System.out.println("[BookDao] insertHopeBook()");
		
		String sql =  "INSERT INTO tbl_hope_book(u_m_no, hb_name, hb_author, hb_publisher, "
					+ "hb_publish_year, hb_reg_date, hb_mod_date, hb_result_last_date) "
					+ "VALUES(?, ?, ?, ?, ?, NOW(), NOW(), NOW())";
		
		int result = -1;
		
		try {
			
			result = jdbcTemplate.update(sql, 
											hopeBookVo.getU_m_no(), 
											hopeBookVo.getHb_name(), 
											hopeBookVo.getHb_author(), 
											hopeBookVo.getHb_publisher(), 
											hopeBookVo.getHb_publish_year());
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return result;
		
	}
	
//	public List<HopeBookVo> selectRequestHopeBooks(int u_m_no) {
//		System.out.println("[BookDao] insertHopeBook()");
//		
//		String sql = "SELECT * FROM tbl_hope_book WHERE u_m_no = ?";
//		
//		List<HopeBookVo> hopeBookVos = null;
//		
//		try {
//			
//			hopeBookVos = jdbcTemplate.query(sql, new RowMapper<HopeBookVo>() {
//
//				@Override
//				public HopeBookVo mapRow(ResultSet rs, int rowNum) throws SQLException {
//					
//					HopeBookVo hopeBookVo = new HopeBookVo();
//					
//					hopeBookVo.setHb_no(rs.getInt("hb_no"));
//					hopeBookVo.setU_m_no(rs.getInt("u_m_no"));
//					hopeBookVo.setHb_name(rs.getString("hb_name"));
//					hopeBookVo.setHb_author(rs.getString("hb_author"));
//					hopeBookVo.setHb_publisher(rs.getString("hb_publisher"));
//					hopeBookVo.setHb_publish_year(rs.getString("hb_publish_year"));
//					hopeBookVo.setHb_reg_date(rs.getString("hb_reg_date"));
//					hopeBookVo.setHb_mod_date(rs.getString("hb_mod_date"));
//					hopeBookVo.setHb_result(rs.getInt("hb_result"));
//					hopeBookVo.setHb_result_last_date(rs.getString("hb_result_last_date"));
//					
//					return hopeBookVo;
//					
//				}
//				
//			}, u_m_no);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			
//		}
//		
//		return hopeBookVos;
//		
//	}

	public List<HopeBookVo> selectRequestHopeBooks(int u_m_no) {
		System.out.println("[BookDao] insertHopeBook()");
		
		String sql = "SELECT * FROM tbl_hope_book WHERE u_m_no = ?";
		
		List<HopeBookVo> hopeBookVos = null;
		
		try {
			
			RowMapper<HopeBookVo> rowMapper = BeanPropertyRowMapper.newInstance(HopeBookVo.class);
			hopeBookVos = jdbcTemplate.query(sql, rowMapper, u_m_no);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
		return hopeBookVos;
		
	}
	
}
